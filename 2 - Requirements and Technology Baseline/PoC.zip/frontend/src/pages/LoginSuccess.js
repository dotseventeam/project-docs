import React from 'react'

export default function Login() {
    return (
        <div>
            <p>You successfully logged in!</p>
        </div>
    );
}