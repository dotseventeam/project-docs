import React from 'react'


export default function Home() {
    return (
        <div className='container'>
            <p>Go to the login page to try out our CAPTCHA!</p>
        </div>
    );
}