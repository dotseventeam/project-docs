import React from 'react'

export default function Login() {
    return (
        <div>
            <p>Your login attempt failed. Retry now!</p>
        </div>
    );
}