INSERT INTO users
    (username, password)
VALUES('dotseven', 'dotsevenpoc');
