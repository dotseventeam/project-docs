DROP TABLE IF EXISTS users;
CREATE TABLE users
(
    username VARCHAR(25) PRIMARY KEY,
    password VARCHAR(25),
);